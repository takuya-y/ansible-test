Rails.application.routes.draw do
  resources :topic
end
