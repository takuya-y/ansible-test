### README

#### 概要
RSSリーダー
ITmediaのRSSから読み込んだデータをMySQLデータベースに入れて表示するだけ
